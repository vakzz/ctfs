from flask import Flask, jsonify, request, make_response, send_file
import os
from subprocess32 import run, STDOUT, PIPE, CalledProcessError

app = Flask(__name__)

@app.route("/api/encoder", methods=['POST'])
def encode():
    try:
        data = request.get_json(force=True)
    except Exception:
        return make_response(jsonify({'status': 400, 'message': 'Malformed request'}), 400)
    if not (('length' in data) and ('data' in data)):
        return make_response(jsonify({'status': 400, 'message': 'Invalid request'}), 400)
    try:
        bin_data = data['data'].decode('hex')
    except TypeError:
        return make_response(jsonify({'status': 400, 'message': 'Can\'t decode payload'}), 400)
    try:
        bin_length = int(data['length'])
    except ValueError:
        return make_response(jsonify({'status': 400, 'message': 'Can\'t get payload\'s length'}), 400)
    try:
    	result = run(['./encodr_bin', str(bin_length)], input=bin_data, stdout=PIPE, stderr=STDOUT, timeout=2, check=True).stdout
    except CalledProcessError:
    	return make_response(jsonify({'status': 400, 'message': 'The program crashed, are you trying to hack me =='}), 400)
    return jsonify({'status': 200, 'message': result.encode('hex')})

@app.route('/<path:path>')
def route_frontend(path):
    file_path = os.path.join(app.static_folder, path)
    if os.path.isfile(file_path):
        return send_file(file_path)
    else:
        index_path = os.path.join(app.static_folder, 'index.html')
        return send_file(index_path)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)